sap.ui.define([
	"com/emax/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"com/emax/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageToast",
	"sap/m/MessageBox"
], function (BaseController, JSONModel, History, formatter, Filter, FilterOperator, MessageToast, MessageBox) {
	"use strict";
	return BaseController.extend("com.emax.controller.Worklist", {
		formatter: formatter,
		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */
		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		_refresh: function () {
			this.onInit();
		},
		onInit: function () {
			var oViewModel, iOriginalBusyDelay, oTable = this.byId("table");
			// Put down worklist table's original value for busy indicator delay,
			// so it can be restored later on. Busy handling on the table is
			// taken care of by the table itself.
			// iOriginalBusyDelay = oTable.getBusyIndicatorDelay();
			this._oTable = oTable;
			// keeps the search state
			this._oTableSearchState = [];
			// Model used to manipulate control states
			oViewModel = new JSONModel({
				worklistTableTitle: this.getResourceBundle().getText("worklistTableTitle"),
				saveAsTileTitle: this.getResourceBundle().getText("saveAsTileTitle", this.getResourceBundle().getText("worklistViewTitle")),
				shareOnJamTitle: this.getResourceBundle().getText("worklistTitle"),
				shareSendEmailSubject: this.getResourceBundle().getText("shareSendEmailWorklistSubject"),
				shareSendEmailMessage: this.getResourceBundle().getText("shareSendEmailWorklistMessage", [location.href]),
				tableNoDataText: this.getResourceBundle().getText("tableNoDataText"),
				tableBusyDelay: 0
			});
			this.setModel(oViewModel, "worklistView");
			// Make sure, busy indication is showing immediately so there is no
			// break after the busy indication for loading the view's meta data is
			// ended (see promise 'oWhenMetadataIsLoaded' in AppController)
			// oTable.attachEventOnce("updateFinished", function(){
			// 	// Restore original busy indicator delay for worklist's table
			// 	oViewModel.setProperty("/tableBusyDelay", iOriginalBusyDelay);
			// });
			// SAP OData Services
			this.data = "/SAPODataEMAX/sap/opu/odata/IWBEP/GWSAMPLE_BASIC/";
			// copy this from the manifest.json			
			var odatamodel1 = new sap.ui.model.odata.ODataModel(this.data);
			this.jsonmodel1 = new JSONModel();
			//repeated namespaces declare on the top
			// Enhancment:1011: Code added by Karthik
			var that = this;
			odatamodel1.read("ProductSet", {
				success: function (oData, response) {
					that.jsonmodel1.setData(oData.results);
					// below code is used for Table control
					that.getView().byId("table1").setModel(that.jsonmodel1, "prod");
					// below code is used for Dynamic Select Control
					that.getView().byId("iddyn").setModel(that.jsonmodel1, "prod");
				},
				error: function (msg) {
					MessageToast.show("Failed: " + msg);
				}
			});
			// SalesOrderSet
			var jsonmodelsales = new JSONModel();
			odatamodel1.read("SalesOrderSet", {
				success: function (oData, response) {
					jsonmodelsales.setData(oData.results);
					that.getView().byId("table3").setModel(jsonmodelsales, "sales");
				},
				error: function (msg) {
					MessageToast.show("Failed: " + msg);
				}
			}); // Northwind OData
			// var data_nw = "/SAPODataEMAX/V2/Northwind/Northwind.svc/"; // copy this from the manifest.json			
			// var odatamodelnw = new sap.ui.model.odata.ODataModel(data_nw);
			// var jsonmodelnw = new JSONModel(); //repeated namespaces declare on the top
			// //var that = this;
			// odatamodelnw.read("Products", {
			// 	success: function (oData, response) {
			// 		jsonmodelnw.setData(oData.results);
			// 		that.getView().byId("tablenw").setModel(jsonmodelnw, "nprod");
			// 	},
			// 	error: function (msg) {
			// 		MessageToast.show("Failed: " + msg);
			// 	}
			// });
			// OData Test
		},
		_orderbyprice: function () {
			var odatamodel1 = new sap.ui.model.odata.ODataModel(this.data);
			var jsonmodeloby = new JSONModel();
			var that = this;
			odatamodel1.read("ProductSet?$orderby=Price", {
				success: function (oData, response) {
					jsonmodeloby.setData(oData.results);
					that.getView().byId("table1").setModel(jsonmodeloby, "prod");
				},
				error: function (msg) {
					MessageToast.show("Failed: " + msg);
				}
			});
		},
		_pricelt100: function () {
			var odatamodel1 = new sap.ui.model.odata.ODataModel(this.data);
			var jsonmodeloby = new JSONModel();
			var filter1 = new sap.ui.model.Filter("Price", "LT", "100");
			var that = this;
			odatamodel1.read("ProductSet", {
				filters: [filter1],
				success: function (oData, response) {
					jsonmodeloby.setData(oData.results);
					that.getView().byId("table1").setModel(jsonmodeloby, "prod");
				},
				error: function (msg) {
					MessageToast.show("Failed: " + msg);
				}
			});
		},
		_priceandcategory: function () {
			var odatamodel1 = new sap.ui.model.odata.ODataModel(this.data);
			var jsonmodeloby = new JSONModel();
			var filter1 = new sap.ui.model.Filter("Price", "LT", "1000");
			var filter2 = new sap.ui.model.Filter("Category", "EQ", "Notebooks");
			var that = this;
			odatamodel1.read("ProductSet", {
				filters: [
					filter1,
					filter2
				],
				success: function (oData, response) {
					jsonmodeloby.setData(oData.results);
					that.getView().byId("table1").setModel(jsonmodeloby, "prod");
				},
				error: function (msg) {
					MessageToast.show("Failed: " + msg);
				}
			});
		},
		_priceorcategory: function () {
			var odatamodel1 = new sap.ui.model.odata.ODataModel(this.data);
			var jsonmodeloby = new JSONModel();
			var filter1 = new sap.ui.model.Filter("Price", "LT", "1000");
			var filter2 = new sap.ui.model.Filter("Category", "EQ", "Notebooks");
			var that = this;
			odatamodel1.read("ProductSet", {
				filters: [new Filter([
					filter1,
					filter2
				], false)],
				success: function (oData, response) {
					jsonmodeloby.setData(oData.results);
					that.getView().byId("table1").setModel(jsonmodeloby, "prod");
				},
				error: function (msg) {
					MessageToast.show("Failed: " + msg);
				}
			});
		},
		_pricebt10_30: function () {
			var odatamodel1 = new sap.ui.model.odata.ODataModel(this.data);
			var jsonmodeloby = new JSONModel();
			var filter3 = new Filter("Price", FilterOperator.BT, "10", "30");
			var that = this;
			odatamodel1.read("ProductSet", {
				filters: [filter3],
				success: function (oData, response) {
					jsonmodeloby.setData(oData.results);
					that.getView().byId("table1").setModel(jsonmodeloby, "prod");
				},
				error: function (msg) {
					MessageToast.show("Failed: " + msg);
				}
			});
		},
		_statsel: function () {
			var keys = this.byId("idstat").getSelectedKey();
			MessageToast.show(keys);
			if (keys === "0") {
				this._refresh();
			}
			if (keys === "1") {
				this._orderbyprice();
			}
			if (keys === "2") {
				this._pricelt100();
			}
			if (keys === "3") {
				this._priceandcategory();
			}
			if (keys === "4") {
				this._priceorcategory();
			}
			if (keys === "5") {
				this._pricebt10_30();
			}
		},
		_dynsel: function (oEvent) {
			var pid = oEvent.getParameter("selectedItem").getText();
			var odatamodel1 = new sap.ui.model.odata.ODataModel(this.data);
			var jsonmodel1 = new JSONModel();
			var filter1 = new sap.ui.model.Filter("ProductID", "EQ", pid);
			var that = this;
			odatamodel1.read("ProductSet", {
				filters: [filter1],
				success: function (oData, response) {
					jsonmodel1.setData(oData.results);
					that.getView().byId("table1").setModel(jsonmodel1, "prod");
				},
				error: function (msg) {
					MessageToast.show("Failed: " + msg);
				}
			});
		},
		_radsel: function (oEvent) {
			var bc = oEvent.getSource().getBindingContext("prod");
			if (oEvent.getParameter("selected")) {
				var pid = bc.getProperty("ProductID");
				var cat = bc.getProperty("Category");
				var price = bc.getProperty("Price");
				MessageBox.alert(pid + "-" + cat + "-" + price);
			}
		},
		_hellofrag: function () {
			if (!this.hellofrag) {
				this.hellofrag = sap.ui.xmlfragment(this.getView().getId(), "com.emax.fragments.Hello", this);
				this.getView().addDependent(this.hellofrag);
			}
			this.hellofrag.open();
		},
		onHelloOk: function () {
			this.hellofrag.close();
		},
		_tosupplier: function () {
			// create a fragment is it doesnot exist.
			if (!this.supp) {
				this.supp = sap.ui.xmlfragment(this.getView().getId(), "com.emax.fragments.ToSupplier", this);
				this.getView().addDependent(this.supp);
			}
			this.supp.open();
			// get the supplier data
			var odatamodel1 = new sap.ui.model.odata.ODataModel(this.data);
			var jsonmodel1 = new JSONModel();
			var that = this;

			var jsonarray = [];
			var finalarray = [];
		this.byId("tablesupp").setBusy(true);
			odatamodel1.read("ProductSet", {
				"urlParameters": {
					"$expand": ["ToSupplier"]
				},
				success: function (data) {
					for (var i = 0; i < data.results.length; ++i) {
						var supdata = data.results[i].ToSupplier;
						finalarray.push(supdata);
					}
					jsonarray = {
						"res1": finalarray
					};
					jsonmodel1.setData(jsonarray);
					that.getView().byId("tablesupp").setModel(jsonmodel1, "sup");
					that.byId("tablesupp").setBusy(false);

				},
				error: function () {}
			});

		},
		onsuppOk: function () {
			this.supp.close();
		},
		_tolinegraph: function () {
			if (!this.toline) {
				this.toline = sap.ui.xmlfragment(this.getView().getId(), "com.emax.fragments.GraphLine", this);
				this.getView().addDependent(this.toline);
			}
			this.toline.open();
			// apply the vizframe chart properties here
			var oVizframe = this.getView().byId("idVizFrame");
			oVizframe.setModel(this.jsonmodel1, "prod");
			// make jsonmodel1 global
			oVizframe.setVizProperties({
				plotArea: {
					dataLabel: {
						visible: true
					}
				},
				valueAxis: {
					title: {
						visible: true
					}
				},
				categoryAxis: {
					title: {
						visible: true
					}
				},
				title: {
					visible: true,
					text: "ProductID vs Width&Depth"
				}
			});
		},
		onlineOk: function () {
			this.toline.close();
		},
		_owntabledata: function () {
			if (!this.owntable) {
				this.owntable = sap.ui.xmlfragment(this.getView().getId(), "com.emax.fragments.OwnTable", this);
				this.getView().addDependent(this.owntable);
			}
			this.owntable.open();
			var odatamodel1 = new sap.ui.model.odata.ODataModel(this.data);
			var jsonmodel1 = new JSONModel();
			var finalarray = [];
			var that = this;
			odatamodel1.read("ProductSet", {
				success: function (oData, response) {
					for (var i = 0; i < oData.results.length; ++i) {
						var data = {
							"pid": oData.results[i].ProductID + "<------>",
							"price": oData.results[i].Price,
							"mrp": Number(oData.results[i].Price) + 10
						};
						finalarray.push(data);
					}
					var jsonarray = {
						"results": finalarray
					};
					jsonmodel1.setData(jsonarray);
					that.getView().byId("tableowntable").setModel(jsonmodel1, "own");
					sap.ui.getCore().byId("tableowntable").setModel(jsonmodel1, "own");
				},
				error: function (msg) {
					MessageToast.show("Failed: " + msg);
				}
			});
		},
		onowntableOk: function () {
			this.owntable.close();
		},
		_waterfallgraph: function () {
			if (!this.waterfall) {
				this.waterfall = sap.ui.xmlfragment(this.getView().getId(), "com.emax.fragments.GraphWaterfall", this);
					this.getView().addDependent(this.waterfall);
			}
			this.waterfall.open();
			
			var oVizFrame = this.oVizFrame = this.getView().byId("idVizFramewaterfall");
			oVizFrame.setModel(this.jsonmodel1,"water");
			 oVizFrame.setVizProperties({
                plotArea: {
                    dataLabel: {
                       
                        visible: true
                    }
                },
                valueAxis: {
                    
                    title: {
                        visible: true
                    }
                },
                categoryAxis: {
                    title: {
                        visible: true
                    }
                },
                legend: {
                    title: {
                        visible: true
                    },
                   
                },
                title: {
                    visible: true,
                    text: 'ProductID by Weight and Price'
                }
            });
		},
		onWaterfallOk: function () {
			this.waterfall.close();
		},
		_tocontactset : function(){
			if(!this.contactset){
			this.contactset = sap.ui.xmlfragment(this.getView().getId(), "com.emax.fragments.ContactSet",this);
			this.getView().addDependent(this.contactset);
			}
			this.contactset.open();
			
			var odatamodel = new sap.ui.model.odata.ODataModel(this.data);
			var jsonmodel1 = new sap.ui.model.json.JSONModel();
			var that = this;
			this.byId("tablecset").setBusy(true);
		
			
			odatamodel.read("ContactSet",{
				success : function(odata){
					jsonmodel1.setData(odata.results);
					that.getView().byId("tablecset").setModel(jsonmodel1,"cset");
					that.byId("tablecset").setBusy(false);
				},
				error : function(){
					
				}
			});
			
			
		},
		onContactSetOk : function(){
			this.contactset.close();
		},
		_tocountryset: function(){
				if(!this.countryset){
			this.countryset = sap.ui.xmlfragment(this.getView().getId(), "com.emax.fragments.VH_CountrySet",this);
			this.getView().addDependent(this.countryset);
			}
			this.countryset.open();
			
			var odatamodel = new sap.ui.model.odata.ODataModel(this.data);
			var jsonmodel1 = new sap.ui.model.json.JSONModel();
			var that = this;
			this.byId("tablevhcountry").setBusy(true);
			var jsonarray = [];
			var finalarray = [];
			
			
			odatamodel.read("VH_CountrySet",{
				success : function(odata){
					for(var i = 0;i<odata.results.length;++i){
						var a = odata.results[i].Land1;
						var b = odata.results[i].Landx;
						
					var countdata = {
							land1 : odata.results[i].Land1,
							landx : odata.results[i].Landx,
							natio : odata.results[i].Natio,
							c : a.concat("-",b)
						};
						finalarray.push(countdata);
					}
					jsonarray = {
						"allres" : finalarray
					};
					jsonmodel1.setSizeLimit(1000);
					jsonmodel1.setData(jsonarray);
					that.getView().byId("tablevhcountry").setModel(jsonmodel1,"count");
					
					that.getView().byId("TreeTableBasic").setModel(jsonmodel1,"count");
				//	that.getView().byId("idsel11").setModel(jsonmodel1,"count1");
					that.byId("tablevhcountry").setBusy(false);
				},
				error : function(){
					
				}
			});
		},
		onCountryOk : function(){
				this.countryset.close();
		},
		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */
		/**
		 * Triggered by the table's 'updateFinished' event: after new table
		 * data is available, this handler method updates the table counter.
		 * This should only happen if the update was successful, which is
		 * why this handler is attached to 'updateFinished' and not to the
		 * table's list binding's 'dataReceived' method.
		 * @param {sap.ui.base.Event} oEvent the update finished event
		 * @public
		 */
		onUpdateFinished: function (oEvent) {
			// update the worklist's object counter after the table update
			var sTitle, oTable = oEvent.getSource(),
				iTotalItems = oEvent.getParameter("total");
			// only update the counter if the length is final and
			// the table is not empty
			if (iTotalItems && oTable.getBinding("items").isLengthFinal()) {
				sTitle = this.getResourceBundle().getText("worklistTableTitleCount", [iTotalItems]);
			} else {
				sTitle = this.getResourceBundle().getText("worklistTableTitle");
			}
			this.getModel("worklistView").setProperty("/worklistTableTitle", sTitle);
		},
		/**
		 * Event handler when a table item gets pressed
		 * @param {sap.ui.base.Event} oEvent the table selectionChange event
		 * @public
		 */
		onPress: function (oEvent) {
			// The source is the list item that got pressed
			this._showObject(oEvent.getSource());
		},
		/**
		 * Event handler when the share in JAM button has been clicked
		 * @public
		 */
		onShareInJamPress: function () {
			var oViewModel = this.getModel("worklistView"),
				oShareDialog = sap.ui.getCore().createComponent({
					name: "sap.collaboration.components.fiori.sharing.dialog",
					settings: {
						object: {
							id: location.href,
							share: oViewModel.getProperty("/shareOnJamTitle")
						}
					}
				});
			oShareDialog.open();
		},
		onSearch: function (oEvent) {
			if (oEvent.getParameters().refreshButtonPressed) {
				// Search field's 'refresh' button has been pressed.
				// This is visible if you select any master list item.
				// In this case no new search is triggered, we only
				// refresh the list binding.
				this.onRefresh();
			} else {
				var oTableSearchState = [];
				var sQuery = oEvent.getParameter("query");
				if (sQuery && sQuery.length > 0) {
					oTableSearchState = [new Filter("SupplierName", FilterOperator.Contains, sQuery)];
				}
				this._applySearch(oTableSearchState);
			}
		},
		/**
		 * Event handler for refresh event. Keeps filter, sort
		 * and group settings and refreshes the list binding.
		 * @public
		 */
		onRefresh: function () {
			this._oTable.getBinding("items").refresh();
		},
		/* =========================================================== */
		/* internal methods                                            */
		/* =========================================================== */
		/**
		 * Shows the selected item on the object page
		 * On phones a additional history entry is created
		 * @param {sap.m.ObjectListItem} oItem selected Item
		 * @private
		 */
		_showObject: function (oItem) {
			this.getRouter().navTo("object", {
				objectId: oItem.getBindingContext().getProperty("ProductID")
			});
		},
		/**
		 * Internal helper method to apply both filter and search state together on the list binding
		 * @param {object} oTableSearchState an array of filters for the search
		 * @private
		 */
		_applySearch: function (oTableSearchState) {
			var oViewModel = this.getModel("worklistView");
			this._oTable.getBinding("items").filter(oTableSearchState, "Application");
			// changes the noDataText of the list in case there are no filter results
			if (oTableSearchState.length !== 0) {
				oViewModel.setProperty("/tableNoDataText", this.getResourceBundle().getText("worklistNoDataWithSearchText"));
			}
		},
		/**
		 *@memberOf com.emax.controller.Worklist
		 */
		action: function (oEvent) {
			var that = this;
			var actionParameters = JSON.parse(oEvent.getSource().data("wiring").replace(/'/g, "\""));
			var eventType = oEvent.getId();
			var aTargets = actionParameters[eventType].targets || [];
			aTargets.forEach(function (oTarget) {
				var oControl = that.byId(oTarget.id);
				if (oControl) {
					var oParams = {};
					for (var prop in oTarget.parameters) {
						oParams[prop] = oEvent.getParameter(oTarget.parameters[prop]);
					}
					oControl[oTarget.action](oParams);
				}
			});
			var oNavigation = actionParameters[eventType].navigation;
			if (oNavigation) {
				var oParams = {};
				(oNavigation.keys || []).forEach(function (prop) {
					oParams[prop.name] = encodeURIComponent(JSON.stringify({
						value: oEvent.getSource().getBindingContext(oNavigation.model).getProperty(prop.name),
						type: prop.type
					}));
				});
				if (Object.getOwnPropertyNames(oParams).length !== 0) {
					this.getOwnerComponent().getRouter().navTo(oNavigation.routeName, oParams);
				} else {
					this.getOwnerComponent().getRouter().navTo(oNavigation.routeName);
				}
			}
		}
	});
});