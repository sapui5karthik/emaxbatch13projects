jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
		"sap/ui/test/Opa5",
		"com/emax/test/integration/pages/Common",
		"sap/ui/test/opaQunit",
		"com/emax/test/integration/pages/Worklist",
		"com/emax/test/integration/pages/Object",
		"com/emax/test/integration/pages/NotFound",
		"com/emax/test/integration/pages/Browser",
		"com/emax/test/integration/pages/App"
	], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "com.emax.view."
	});

	sap.ui.require([
		"com/emax/test/integration/WorklistJourney",
		"com/emax/test/integration/ObjectJourney",
		"com/emax/test/integration/NavigationJourney",
		"com/emax/test/integration/NotFoundJourney",
		"com/emax/test/integration/FLPIntegrationJourney"
	], function () {
		QUnit.start();
	});
});